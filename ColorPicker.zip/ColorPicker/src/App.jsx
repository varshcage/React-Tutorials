import Pick from "./Pick.jsx";
import './App.css'

function App() {

  return (
    <>
    <Pick />
    </>
  );
}

export default App
