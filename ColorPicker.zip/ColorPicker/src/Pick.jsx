import { useState } from "react";

function Pick(){
const [color1,setColor1] =   useState("red");
const[color2,setColor2] = useState("blue");

function handleColor(event){
setColor1(event.target.value);
}

function handleColor2(event){
setColor2(event.target.value);
}

return(

        <div className="picker">
            <h1>Color Picker</h1>
<div className="palatte" 
style={{background: `linear-gradient(to right, ${color1}, ${color2})`}}>
</div>
<br></br>
<div className="inputs">
<label>select color 1</label>
<input type="color" value={color1} onChange={handleColor} />
<label>select color 2</label>
<input type="color" value={color2} onChange={handleColor2} />
</div>
</div>
    );

}

export default Pick;